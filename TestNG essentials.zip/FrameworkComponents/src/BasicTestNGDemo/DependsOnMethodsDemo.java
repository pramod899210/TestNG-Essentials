package BasicTestNGDemo;

import org.testng.Assert;
import org.testng.annotations.Test;

public class DependsOnMethodsDemo {
		//Initially the methods are executed in alphabetical order when without priority
	
	 @Test(priority=1, invocationCount = 5)       //invocationCount usage to execute a method multiple times
	  public void register() {
		  System.out.println("First time user Registration");
		 
	  }
	 
	 @Test(enabled=false)                           //enabled=false usage to ignore a method execution
	  public void register2() {
		  System.out.println("user Registration_2");
		 
	  }
	 
	@Test
	  public void login() {
		  System.out.println("Existing User Login");
		  Assert.assertTrue(false);
	  }
	
	 @Test(dependsOnMethods="login")
	 public void searchFlights() {
		  System.out.println("Flight Search");
		  
	  }
	 
}

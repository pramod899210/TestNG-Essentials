package BasicTestNGDemo;

import org.testng.annotations.Test;

public class TimeOutDemo {

	@Test(timeOut=100)
	public void timeoutendless() {
		int i=1;
		while(i==1) {
			System.out.println(i);
		}
	}
}

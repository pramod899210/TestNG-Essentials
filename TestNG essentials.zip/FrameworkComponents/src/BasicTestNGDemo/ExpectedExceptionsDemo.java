package BasicTestNGDemo;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class ExpectedExceptionsDemo {

	 @Test(groups= {"Smoke","Functional"}, expectedExceptions = ArithmeticException.class )
	  public void mobileapplogin() {
		  System.out.println("@Test mobileapplogin");
		 int x=9/0;
		 System.out.println(x);
	  }
	 @Test(groups= {"Functional"})
	  public void mobileflightsearch() {
		  System.out.println("@Test mobilesitelogin");
	  }
	 @Test(groups= {"Smoke","Functional"})
	  public void desktopapplogin() {
		  System.out.println("@Test desktopapplogin");
		
	  }
	  @Test(groups= {"Functional"} )
	  public void desktopflightsearch() {
		  System.out.println("@Test desktopsitelogin");
	  }
	 
	

}

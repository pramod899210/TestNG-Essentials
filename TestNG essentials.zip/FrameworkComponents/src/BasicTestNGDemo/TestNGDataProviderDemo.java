package BasicTestNGDemo;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class TestNGDataProviderDemo {
	

	@Test(dataProvider = "getData")
	public void login(String username, String Password) {
		System.out.println("User Name: "+ username);
		System.out.println("Password: "+ Password);
	}

@DataProvider
public Object[][] getData() {
	
	Object obj[][]= new Object[3][2];
	obj[0][0]="User_A";
	obj[0][1]="A10$";
	obj[1][0]="User_B";
	obj[1][1]="B20#";
	obj[2][0]="User_C";
	obj[2][1]="C30@";
	
	return obj;
}

}

package BasicTestNGDemo;

import org.testng.annotations.Test;

public class GroupsDemo {

	 @Test(groups = { "functest", "smoketest" })
	  public void winMethod1() {System.out.println("test1");
	  }
	 
	  @Test(groups = {"functest", "smoketest"} )
	  public void winMethod2() {System.out.println("test2");
	  }
	 
	  @Test(groups = { "functest" })
	  public void LinuxMethod3() {System.out.println("test3");
	  }

}

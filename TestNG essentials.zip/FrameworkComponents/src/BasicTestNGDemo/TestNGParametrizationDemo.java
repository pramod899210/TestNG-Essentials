package BasicTestNGDemo;


import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class TestNGParametrizationDemo {
	
@Parameters({"URL"})
	@Test
	public void login(String url) {
		System.out.println(url);
		//System.out.println(username);
	}


}

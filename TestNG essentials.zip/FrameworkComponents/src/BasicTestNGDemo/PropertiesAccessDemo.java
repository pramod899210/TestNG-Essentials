package BasicTestNGDemo;


	import java.io.FileInputStream;

	import java.io.FileOutputStream;

	import java.io.IOException;

	import java.util.Properties;



	public class PropertiesAccessDemo {



	public static void main(String[] args) throws IOException {

	// TODO Auto-generated method stub



	Properties prop=new Properties();

	FileInputStream fis =new FileInputStream("D:\\IDE_Selenium\\FrameworkComponents\\TestData\\data1.properties");

	prop.load(fis);

	System.out.println(prop.getProperty("browser"));


	prop.setProperty("browser", "firefox");

	System.out.println(prop.getProperty("browser"));

	FileOutputStream fos =new FileOutputStream("D:\\IDE_Selenium\\FrameworkComponents\\TestData\\data1.properties");

	prop.store(fos, null);

	}



	}


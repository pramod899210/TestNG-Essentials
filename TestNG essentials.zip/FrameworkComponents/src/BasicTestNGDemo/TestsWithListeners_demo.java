package BasicTestNGDemo;

import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners({BasicTestNGDemo.ListenersDeclaration.class})
public class TestsWithListeners_demo {

@Test
public void Failedtest() {
	System.out.println("I am going to fail now");
	Assert.assertTrue(false);
}
@Test(dependsOnMethods="Failedtest")
public void Skippedtest() {
	System.out.println("I am going to be skipped now");
	
}
@Test
public void sum() {
	System.out.println("I am going to succeed now");
	System.out.println(1+2);
	
}
}

package BasicTestNGDemo;

public class StringEqualsdemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s1="ASD";
String s2=s1;
String s3=new String("ASD");

System.out.println(s1==s2);
System.out.println(s1.equals(s2));

System.out.println(s1==s3);
System.out.println(s1.equals(s3));
	}

}

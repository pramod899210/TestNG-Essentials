package BasicTestNGDemo;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TestNGtest2 {
 
	@BeforeMethod
	  public void beforeMethod() { System.out.println("@BeforeMethod2");
	  }

	  @AfterMethod
	  public void afterMethod() {System.out.println("@AfterMethod2");
	  }

	  @BeforeClass
	  public void beforeClass() {System.out.println("@BeforeClass2");
	  }

	  @AfterClass
	  public void afterClass() {System.out.println("@AfterClass2");
	  }
	  @BeforeTest
	  public void beforeTest() {System.out.println("@BeforeTest2");
	  }

	  @AfterTest
	  public void afterTest() {System.out.println("@AfterTest2");
	  }
	  @BeforeSuite
	  public void beforeSuite() {System.out.println("@BeforeSuite2");
	  }

	  @AfterSuite
	  public void afterSuite() {System.out.println("@AfterSuite2");
	  }
	@Test(priority=7, groups= {"smoke", "functional"})
	public void work1() {
		System.out.println("TestNG1 installed");
	}
	@Test(priority=8, groups={"smoke", "functional"})
	public void work5() {
		System.out.println("TestNG5 installed");
	}
	@Test(priority=9, groups={"smoke"})
	public void work4() {
		System.out.println("TestNG4 installed");
	}
	@Test(priority=10, groups={"functional"})
	public void work3() {
		System.out.println("TestNG3 installed");
	}
}
